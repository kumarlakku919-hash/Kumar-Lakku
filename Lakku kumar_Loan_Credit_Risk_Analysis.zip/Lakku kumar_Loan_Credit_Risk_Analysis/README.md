# Loan Default & Credit Risk Analysis
Folder Structure:
StudentName_Loan_Credit_Risk_Analysis/
├── Dataset/
│   └── Loan_Credit_Risk_Cleaned.csv
├── Python/
│   └── Loan_Credit_Risk_Analysis.ipynb
├── PowerBI/
│   └── Loan_Credit_Risk_Dashboard.pbix
├── Report/
│   └── Loan_Credit_Risk_Project_Report.pdf
└── README.md
Key Results: Default Rate ~30%, Personal loans highest risk, Low credit <600, High DTI >40%, Previous defaults strong predictor
