# Customer Churn Analysis - Complete Project Submission

## Folder Structure
```
StudentName_Customer_Churn_Analysis/
├── Dataset/
│   └── Customer_Churn_Cleaned.csv
├── Python/
│   └── Customer_Churn_Analysis.ipynb
├── Charts/ (14 PNG files)
├── Report/
│   └── Customer_Churn_Project_Report.docx
└── README.md
```

## How to Use
1. Python: Open Customer_Churn_Analysis.ipynb in Jupyter/Colab and Run All
2. Power BI: Import Customer_Churn_Cleaned.csv and build dashboard using the guide
3. Report: Open .docx, add your name, insert chart PNGs, export as PDF

## Key Results
- Overall Churn Rate: 35.5%
- Highest Risk: Month-to-month + Fiber + Electronic check + New customers
- Recommendation: Push annual contracts + auto-pay + bundle services
